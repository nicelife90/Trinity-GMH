﻿--**********************************************************************
--$Author: Maven $
--**********************************************************************
-- SavedVariables
TicketChannel = "gm_sync_channel";
savedannflag = {};
savedannmsg = {};

function OpenMain()
	if(gmhview == 2) then
		MinipForm:Show();
	elseif(gmhview == 3) then
		MiniForm:Show();
	else
		FullForm:Show();
	end
end

function ToggleAddon()
	if( addonopen == 1 ) then
		ItemFormSearch:Hide();
		FullForm:Hide();
		MinipForm:Hide();
		MiniForm:Hide();
		BattlegroundForm:Hide();
		CommForm:Hide();
		ItemForm:Hide();
		MiscForm:Hide();
		ObjectForm:Hide();
		TicketTracker:Hide();
		TicketView:Hide();
		TeleForm:Hide();
		ProfessionsForm:Hide();
		SkillForm:Hide();
		SpellForm:Hide();
		BanForm:Hide();
		NPCForm:Hide();
		AnnounceForm:Hide();
		PlayerForm:Hide();
		ViewForm:Hide();
		WepskForm:Hide();
		OverridesForm:Hide();
		ModifyForm:Hide();
		QuickItemForm:Hide();
		QuestForm:Hide();
		QuickPortalForm:Hide();
		PlaySound( "INTERFACESOUND_CHARWINDOWCLOSE" );
		addonopen = 0;
	else
		OpenMain();
		PlaySound( "INTERFACESOUND_CHARWINDOWOPEN" );
		addonopen = 1;
	end
end

chanvar = "GUILD";
function outSAY( text, BoolChat )
	if (BoolChat == 1) then
		SendChatMessage( ""..text, chanvar );
	else
		SendChatMessage( "."..text, chanvar );
	end
end

--[[ ShowMessage Syntax == ShowMessage( "Message", "Hex Color", Chat Frame(0) or UIErrorsFrame(1) );
Chat Frame == 0 || UIErrorsFrame == 1
Ex. ShowMessage( "GM Helper v1.0.3 loaded!", "00FF00", 1 );  Sends GM Helper v1.0.3 loaded! to UI Errors Frame in the color Green ]]
function ShowMessage( StrMsg, StrHex, BoolFrame )
	local StrHex1,StrHex2,StrHex3 = string.match( StrHex, "(..)(..)(..)" );
	local IntCol1 = ( tonumber( StrHex1, 16 ) / 255 );
	local IntCol2 = ( tonumber( StrHex2, 16 ) / 255 );
	local IntCol3 = ( tonumber( StrHex3, 16 ) / 255 );-- local decstr = tostring( number )
	if(BoolFrame == 1) then
		UIErrorsFrame:AddMessage( StrMsg, IntCol1, IntCol2, IntCol3, 53, 2 );
	else
		DEFAULT_CHAT_FRAME:AddMessage( StrMsg, IntCol1, IntCol2, IntCol3 );
	end
end

function GMHelperOnLoad(self)
	self:RegisterForDrag( "RightButton" );
end

function GMHelper_Loaded()
	ShowMessage( "GM Helper v1.0.3 loaded!", "00FF00" );
end

function PSoundF( file )
	PlaySoundFile( file );
end

function PSound()
	PlaySound( sound );
end

function GMHMinimap_Show()
	GameTooltip:SetOwner( this, "ANCHOR_LEFT" );
	GameTooltip:AddLine( "|cFF00FF00GMH v1.0.3|r" );
	GameTooltip:AddLine( "|cFF00FFCCLeft click to show/hide|r" );
	GameTooltip:AddLine( "|cFFFF0000Right click to drag this|r" );
	GameTooltip:Show();
end

-- Binding Variables
BINDING_HEADER_GMHelper = "GM Helper";
BINDING_NAME_ToggleAddon = "Toggles GM Helper";
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- Ban Script
function BanPlayer()
	outSAY( "ban char "..CharName:GetText().." "..BanReason:GetText().." "..BanLength:GetText() );
end

function BanAccount()
	outSAY( "ban account "..CharName:GetText().." "..BanReason:GetText().." "..BanLength:GetText() );
end

function BanAll()
	outSAY( "ban all "..CharName:GetText().." "..BanReason:GetText().." "..BanLength:GetText() );
end

function UnBanPlayer()
	outSAY( "unban char "..CharName:GetText().." "..BanLength:GetText() );
end

function UnBanAccount()
	outSAY( "unban account "..CharName:GetText() );
end

function AddIPBan()
	outSAY( "ban ip "..IPAddress1:GetText().." "..Duration1:GetText() );
end

function DelIPBan()
	outSAY( "unban ip "..IPAddress1:GetText() );
end

function KickPlayer()
	outSAY( "kickplayer "..CharName:GetText().." "..BanReason:GetText() );
end

function DiscPlayer()
	outSAY( "kick player "..CharName:GetText() );
end

function ParPlayer()
	outSAY( "paralyze "..CharName:GetText() );
end

function UnParPlayer()
	outSAY( "unparalyze "..CharName:GetText() );
end

function PInfo()
	outSAY( "playerinfo "..CharName:GetText() );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- BattlegroundScript
function BGStart()
	outSAY( "battleground startbg" );
end

function BGForceStart()
	outSAY( "battleground forcestart" );
end

function BGInfo()
	outSAY( "battleground bginfo" );
end

function BGLeave()
	outSAY( "battleground leave" );
end

function BGGetQueue()
	outSAY( "battleground getqueue" );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- CommScript
function AnnounceChecked()
	if( AnnounceCheck:GetChecked() or ScreenCheck:GetChecked() or GMAnnounceCheck:GetChecked() ) then
		Announce();
	else
		ShowMessage( "Please choose where to Announce!", "FF0000" );
	end
end

function Announce()
	local ArrCheck = { AnnounceCheck:GetChecked(), ScreenCheck:GetChecked(), GMAnnounceCheck:GetChecked() };
	local ArrChan = { "announce ", "wannounce ", "gmannounce " };
	for a = 1, 3 do
		if( ArrCheck[a] ) then
			outSAY( ArrChan[a]..AnnounceText:GetText() );
		end
	end
end

function WhisperOn()
	outSAY( "gm allowwhispers "..PlayerName2:GetText() );
end

function WhisperOff()
	outSAY( "gm blockwhispers "..PlayerName2:GetText() );
end

function SaveAnnSend( a )
	local b = savedannflag[a];
	if( savedannmsg[a] ) then
		if( b >= 4 ) then outSAY( "gmannounce "..savedannmsg[a] ); b = b - 4; end
		if( b >= 2 ) then outSAY( "wannounce "..savedannmsg[a] ); b = b - 2; end
		if( b >= 1 ) then outSAY( "announce "..savedannmsg[a] ); b = b - 1; end
	else
		ShowMessage( "Announcement not set! Please set it in the AnnounceForm.", "FF0000" );
	end
end

function ShowSavedAnn( a )
	if( savedannmsg[a] ) then
		ShowMessage( "Saved Announcement #"..a..": "..savedannmsg[a], "FFFFFF" );
	else
		ShowMessage( "Announcement not set! Please set it in the AnnounceForm.", "FF0000" );
	end
end
-----------------------------------------------------------------------------------------------------------------------------------------------------------
-- AnnounceScript
function SetAnnouncementChecked()
	if( AnnounceCheck:GetChecked() or ScreenCheck:GetChecked() or GMAnnounceCheck:GetChecked() ) then
		Announce();
	else
		ShowMessage( "Please choose where to Announce!", "FF0000" )
	end
end

function SaveAnnStore( a )
	local b = 0;
	if( AnnounceSetCheck:GetChecked() ) then b = b + 1; end
	if( ScreenAnnounceSetCheck:GetChecked() ) then b = b + 2; end
	if( GMAnnounceSetCheck:GetChecked() ) then b = b + 4; end
	if( b > 0 ) then
		savedannmsg[a] = SetAnnounceText:GetText();
		savedannflag[a] = ( b );
		ShowMessage( "Announcement #"..a.." Saved!", "00FF00" );
	else
		ShowMessage( "Please choose where to Announce!", "FF0000" );
	end
end

function GoDownButtonCheck()
local a = SavAnnTxtShow:GetNumber();
if (a >= 2) and (savedannmsg[a]) then
SavAnnTxtShow:SetNumber(a - 1);
end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ItemScript
function RemoveItem()
	outSAY( "character removeitem "..ItemNumber:GetText() );
end

function AddItem()
	if( ItemNumber:GetText() ~= "" ) then
		outSAY( "character additem "..ItemNumber:GetText().." "..ItemQuantity1:GetText() );
	else
		ShowMessage( "Specify an Item Number!", "FF0000", 1 );
	end
end

function AddItemSet()
	outSAY( "character additemset "..ItemSetNumber:GetText() );
end

function SearchItem()
	outSAY( "lookup item "..ItemNumber:GetText() );
end

function AddMoney()
	IntGold = Gold:GetNumber();
	IntSilver = Silver:GetNumber();
	IntCopper = Copper:GetNumber();
	outSAY( "modify gold " ..( ( IntGold * 10000 ) + ( IntSilver * 100 ) + IntCopper ) );
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- MiscScript
function SInfo()
	outSAY( "server info" );
end

function Invis()
	outSAY( "invisible" );
end

function Invince()
	outSAY( "invincible" );
end

function SRestart()
	outSAY( "server restart "..AdminEditBox:GetText() );
end

function SShutdown()
	outSAY( "server shutdown "..AdminEditBox:GetText() );
end

function CancelShutdown()
	outSAY( "server cancelshutdown" );
end

function SaveAll()
	outSAY( "server saveall "..AdminEditBox:GetText() );
end

function MassSummon()
	outSAY( "admin masssummon "..AdminEditBox:GetText() ); -- EditBox not neccessary, but there is an optional argument for the command.
end

function PlayAll()
	outSAY( "admin playall "..AdminEditBox:GetText() );
end

function CastAll()
	outSAY( "admin castall "..AdminEditBox:GetText() );
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--ModifyScript
 function ModSpeed()
	outSAY( "modify speed "..ModifyEditBox:GetText() );
end

function ModHP()
	outSAY( "modify hp "..ModifyEditBox:GetText() );
end

function ModMana()
	outSAY( "modify mana "..ModifyEditBox:GetText() );
end

function ModEnergy()
	outSAY( "modify energy "..ModifyEditBox:GetText() );
end

function ModRage()
	outSAY( "modify rage "..ModifyEditBox:GetText() );
end

function ModResistance()
	outSAY( "modify holy "..ModifyEditBox:GetText() );
	outSAY( "modify fire "..ModifyEditBox:GetText() );
	outSAY( "modify nature "..ModifyEditBox:GetText() );
	outSAY( "modify frost "..ModifyEditBox:GetText() );
	outSAY( "modify shadow "..ModifyEditBox:GetText() );
	outSAY( "modify arcane "..ModifyEditBox:GetText() );
end

function ModArmor()
	outSAY( "modify armor "..ModifyEditBox:GetText() );
end

function ModDamage()
	outSAY( "modify damage "..ModifyEditBox:GetText() );
end

function ModDisplay()
	outSAY( "modify displayid "..ModifyEditBox:GetText() );
end

function Demorph()
	outSAY( "demorph" );
end

function ModSpeed()
	outSAY( "modify speed "..ModifyEditBox:GetText() );
end

function ModScale()
	outSAY( "modify scale "..ModifyEditBox:GetText() );
end

function ModSpirit()
	outSAY( "modify spirit "..ModifyEditBox:GetText() );
end

function ModTP()
	outSAY( "modify talentpoints "..ModifyEditBox:GetText() );
end

function ModFaction()
	outSAY( "modify faction "..ModifyEditBox:GetText() );
end

function ModRunicPower()
	outSAY( "modify runic "..ModifyEditBox:GetText() );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- NPCScript
function AddItemVendor()
	outSAY( "npc vendoradditem "..NPCItemNumber:GetText() );
end

function RemoveItemVendor()
	outSAY( "npc vendorremoveitem "..NPCItemNumber:GetText() );
end

function SpawnNPC()
	outSAY( "npc spawn "..NPCNumber:GetText().." 1" );
end

function LookupNPC()
	outSAY( "lookup creature "..NPCNumber:GetText() );
end

function DeleteNPC()
	outSAY( "npc delete" );
end

function NPCCome()
	outSAY( "npc come" );
end

function NPCPos()
	outSAY( "npc possess" );
end

function NPCUnPos()
	outSAY( "npc unpossess" );
end

function NPCInfo()
	outSAY( "npc info" );
end

function WaypointsAdd()
	outSAY( "waypoint add" );
end

function WaypointsDel()
	outSAY( "waypoint delete" );
end

function WaypointsShow()
	outSAY( "waypoint show" );
end

function WaypointsHide()
	outSAY( "waypoint hide" );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ObjectScript
function TargetObject()
	outSAY( "go select " );
end

function LookupObject()
	outSAY( "lookup object "..ObjectNumber:GetText() );
end

function ObjectScale()
	outSAY( "go scale "..ObjectNumber:GetText() );
end

function ObjectInfo()
	outSAY( "go info " );
end

function DeleteObject()
	outSAY( "go delete " );
end

function PlaceObject()
	if( ObjectNumber:GetText() ~= "" ) then
		PlaceObjectTrue();
	else
		ShowMessage( "Specify an Object Number!", "FF0000", 1 );
	end
end

function PlaceObjectTrue()
	if(NoSaveCheck:GetChecked()) then a = ""; else a = "1"; end
	outSAY("go spawn "..ObjectNumber:GetText().." "..a);
end

function ObjectInfo()
	outSAY( "go info" );
end

function ActivateObject()
	outSAY( "go activate" );
end

function EnableObject()
	outSAY( "go enable" );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- OverridesScript
function CheatStatus()
	outSAY( "cheat status" );
end

function CheatUpdate()
	local a = "";
	if( FlyCheck:GetChecked() ) then a = "on"; else a = "off"; end--fly
	outSAY( "cheat fly "..a );
	if( GodCheck:GetChecked() ) then a = "on"; else a = "off"; end--god
	outSAY( "cheat god "..a );
	if( NCDCheck:GetChecked() ) then a = "on"; else a = "off"; end--cooldown
	outSAY( "cheat cooldown "..a );
	if( NCTCheck:GetChecked() ) then a = "on"; else a = "off"; end--casttime
	outSAY( "cheat casttime "..a );
	if( PowCheck:GetChecked() ) then a = "on"; else a = "off"; end--power
	outSAY( "cheat power "..a );
	if( AuraCheck:GetChecked() ) then a = "on"; else a = "off"; end--stack
	outSAY( "cheat stack "..a );
	if( TrigCheck:GetChecked() ) then a = "on"; else a = "off"; end--triggers
	outSAY( "cheat triggerpass "..a );
end 

function FlySpeed()
if(FlyEntry:GetText() == "") then
Fly_Speed = 7.5;
elseif(FlyEntry:GetText() == "1") then
Fly_Speed = 1;
else
Fly_Speed = FlyEntry:GetText() / 2; --Divide it before it's sent to get the actual desired speed. .mod speed doubles your input for flying.
end
outSAY("mod speed "..Fly_Speed);
end

function FlightPath()
	if(TaxiCheck:GetChecked()) then a = "on"; else a = "off"; end --Taxi
		outSAY("cheat taxi "..a);
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- PlayerScript
 function CreateGuild()
	outSAY( "guild create "..PlayerFormBox:GetText() );
end

function LevelPlayer()
	outSAY( "mod level "..PlayerFormBox:GetText() );
end

function RevivePlayer2()
	outSAY( "reviveplr "..PlayerFormBox:GetText() );
end

function LookupFaction()
	outSAY( "lookup faction "..PlayerFormBox:GetText() );
end

function AchieveComplete()
	outSAY( "achieve complete "..PlayerFormBox:GetText() );
end

function LookupAchievement()
	outSAY( "lookup achievement "..PlayerFormBox:GetText() );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ProfessionsForm
function LearnRiding()
	outSAY( "character learn 33388" );--Apprentice Riding
	outSAY( "character learn 33391" );--Journeyman Riding
	outSAY( "character learn 34090" );--Expert Riding
	outSAY( "character learn 34091" );--Artisan Riding
	outSAY( "character learn 54197" );--Cold Weather Flying
end

function LearnJewel()
	outSAY( "character advancesk 755" );
	outSAY( "character advancesk 755 "..SkillLevel:GetText() );
end

function LearnBlackSmithing()
	outSAY( "character advancesk 164" );
	outSAY( "character advancesk 164 "..SkillLevel:GetText() );
end

function LearnTailoring()
	outSAY( "character advancesk 197" );
	outSAY( "character advancesk 197 "..SkillLevel:GetText() );
end

function LearnLeatherworking()
	outSAY( "character advancesk 165" );
	outSAY( "character advancesk 165 "..SkillLevel:GetText() );
end

function LearnEngineering()
	outSAY( "character advancesk 202" );
	outSAY( "character advancesk 202 "..SkillLevel:GetText() );
end

function LearnPoisons()
	outSAY( "character advancesk 40" );
	outSAY( "character advancesk 40 "..SkillLevel:GetText() );
end

function LearnEnchanting()
	outSAY( "character advancesk 333" );
	outSAY( "character advancesk 333 "..SkillLevel:GetText() );
end

function LearnFishing()
	outSAY( "character advancesk 356" );
	outSAY( "character advancesk 356 "..SkillLevel:GetText() );
end

function LearnMining()
	outSAY( "character advancesk 186" );
	outSAY( "character advancesk 186 "..SkillLevel:GetText() );
end

function LearnSkinning()
	outSAY( "character advancesk 393" );
	outSAY( "character advancesk 393 "..SkillLevel:GetText() );
end

function LearnAlchemy()
	outSAY( "character advancesk 171" );
	outSAY( "character advancesk 171 "..SkillLevel:GetText() );
end

function LearnHerbalism()
	outSAY( "character advancesk 182" );
	outSAY( "character advancesk 182 "..SkillLevel:GetText() );
end

function LearnFirstAid()
	outSAY( "character advancesk 129" );
	outSAY( "character advancesk 129 "..SkillLevel:GetText() );
end

function LearnCooking()
	outSAY( "character advancesk 185" );
	outSAY( "character advancesk 185 "..SkillLevel:GetText() );
end

function LearnInscription()
	outSAY( "character advancesk 773" );
	outSAY( "character advancesk 773 "..SkillLevel:GetText() );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--QuestScript

function LookupQuest()
	outSAY( "lookup quest "..QuestFormBox:GetText() );
end

function QuestComplete()
	outSAY( "quest complete "..QuestFormBox:GetText() );
end

function QuestStart()
	outSAY( "quest start "..QuestFormBox:GetText() );
end

function QuestRemove()
	outSAY( "quest remove "..QuestFormBox:GetText() );
end

function QuestStatus()
	outSAY( "quest status "..QuestFormBox:GetText() );
end

function QuestReward()
	outSAY( "quest reward "..QuestFormBox:GetText() );
end

function QuestSpawn()
if (StartCheckButton:GetChecked() and FinishCheckButton:GetChecked()) then
	ShowMessage("Please select Start or Finish! Not Both!", "FF0000", 1);
elseif (FinishCheckButton:GetChecked()) then
	outSAY("quest finishspawn "..QuestFormBox:GetText());
elseif (StartCheckButton:GetChecked()) then
	outSAY("quest startspawn "..QuestFormBox:GetText());
else
	ShowMessage("Please select Start or Finish!", "FF0000", 1);
end
end

function QuestAdd()
if (StartCheckButton:GetChecked() and FinishCheckButton:GetChecked()) then
	outSAY( "quest addboth "..QuestFormBox:GetText() );
elseif (FinishCheckButton:GetChecked()) then
	outSAY( "quest addfinish "..QuestFormBox:GetText() );
elseif (StartCheckButton:GetChecked()) then
	outSAY( "quest addstart "..QuestFormBox:GetText() );
else
	ShowMessage( "Please select Start, Finish, or Both!", "FF0000", 1 );
end
end

function QuestDel()
if (StartCheckButton:GetChecked() and FinishCheckButton:GetChecked()) then
	outSAY( "quest delboth "..QuestFormBox:GetText() );
elseif (FinishCheckButton:GetChecked()) then
	outSAY( "quest delfinish "..QuestFormBox:GetText() );
elseif (StartCheckButton:GetChecked()) then
	outSAY( "quest delstart "..QuestFormBox:GetText() );
else
	ShowMessage( "Please select Start, Finish, or Both!", "FF0000", 1 );
end
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--QuickItemScript
function GmOutfit()
	outSAY( "character additem 2586" );--Gamemaster's Robe
	outSAY( "character additem 11508" );--Gamemaster's Slippers
	outSAY( "character additem 12064" );--Gamemaster's Hood
	outSAY( "character additem 12947 2" );--Alex's Ring of Audacity X2
	outSAY( "character additem 192" );--Martin Thunder
	outSAY( "character additem 19879" );--Alex's Test Beatdown Staff
	outSAY( "character additem 19160" );--Contest Winner's Tabbard
	outSAY( "character additem 23162 4" );--Foror's Crate of Endless Resist Gear Storage X4
end
--Gamemaster's Robe, Gamemaster's Slippers, Gamemaster's Hood, Alex's Ring of Audacity X2, Martin Thunder, Alex's Test Beatdown Staff, Contest Winner's Tabbard, Foror's Crate of Endless Resist Gear Storage X4

function MageT6()
	outSAY( "character additemset 671" );
end

function HunterT6()
	outSAY( "character additemset 669" );
end

function RogueT6()
	outSAY( "character additemset 668" );
end

function WarlockT6()
	outSAY( "character additemset 670" );
end

function WarriorT6()
	outSAY( "character additemset 673" );
	outSAY( "character additemset 672" );
end

function ShamanT6()
	outSAY( "character additemset 682" );
	outSAY( "character additemset 683" );
	outSAY( "character additemset 684" );
end

function PriestT6()
	outSAY( "character additemset 674" );
	outSAY( "character additemset 675" );
end

function DruidT6()
	outSAY( "character additemset 676" );
	outSAY( "character additemset 677" );
	outSAY( "character additemset 678" );
end

function PaladinT6()
	outSAY( "character additemset 679" );
	outSAY( "character additemset 680" );
	outSAY( "character additemset 681" );
end

function MageT7()
	outSAY( "character additemset 803" );
end

function HunterT7()
	outSAY( "character additemset 794" );
end

function RogueT7()
	outSAY( "character additemset 668" );
end

function WarlockT7()
	outSAY( "character additemset 802" );
end

function WarriorT7()
	outSAY( "character additemset 787" );
	outSAY( "character additemset 788" );
end

function ShamanT7()
	outSAY( "character additemset 795" );
	outSAY( "character additemset 796" );
	outSAY( "character additemset 797" );
end

function PriestT7()
	outSAY( "character additemset 804" );
	outSAY( "character additemset 805" );
end

function DruidT7()
	outSAY( "character additemset 798" );
	outSAY( "character additemset 799" );
	outSAY( "character additemset 800" );
end

function PaladinT7()
	outSAY( "character additemset 789" );
	outSAY( "character additemset 790" );
	outSAY( "character additemset 791" );
end

function DeathKnightT7()
	outSAY( "character additemset 792" );
	outSAY( "character additemset 793" );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- QuickPortalScript
function QPStormwind()
	outSAY( "go spawn 176296 1" );
end

function QPIronforge()
	outSAY( "go spawn 176497 1" );
end

function QPDarnassus()
	outSAY( "go spawn 176498 1" );
end

function QPExodar()
	outSAY( "go spawn 182351 1" );
end

function QPOrgrimmar()
	outSAY( "go spawn 176499 1" );
end

function QPUndercity()
	outSAY( "go spawn 176501 1" );
end

function QPThunderbluff()
	outSAY( "go spawn 176500 1" );
end

function QPSilvermoon()
	outSAY( "go spawn 182352 1" );
end

function QPShattrath()
	outSAY( "go spawn 183384 1" );
end

function QPDalaran()
	outSAY( "go spawn 191164 1" );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- SkillScript
function LookupSkill()
	outSAY( "lookup skill "..SkillNumber:GetText() );
end

function LearnSkill()
	outSAY( "character advancesk "..SkillNumber:GetText().." "..SkillLvl:GetText().." "..SkillMax:GetText() );
end

function UnLearnSkill()
	outSAY( "character removesk "..SkillNumber:GetText() );
end

function AdvanceAll()
	outSAY( "character advanceallskills "..SkillsBy:GetText() );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- SpellScript
function LearnSpell()
	outSAY( "character learn "..SpellNumber:GetText() );
end

function UnlearnSpell()
	outSAY( "character unlearn "..SpellNumber:GetText() );
end

function LearnAll()
	outSAY( "character learn all" );
end

function LookupSpell()
	outSAY( "lookup spell "..SpellNumber:GetText() );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- TeleScript
function GoName()
	outSAY( "appear "..ToPlayerName:GetText() );
end

function NameGo()
	outSAY( "summon "..ToPlayerName:GetText() );
end

function SearchTele()
	outSAY( "recall list " );
end

function Tele()
	outSAY( "recall port "..ZoneName:GetText() );
end

function AddPort()
	outSAY( "recall add "..ZoneName:GetText() );
end

function DelPort()
	outSAY( "recall del "..ZoneName:GetText() );
end

function PortPlayer()
	outSAY( "recall PortPlayer "..ToPlayerName:GetText().." " ..ZoneName:GetText() );
end

function PortUs()
	outSAY( "recall portus "..ZoneName:GetText() );
end

function WorldPort()
	outSAY( "worldport "..MapID:GetText().." "..XCord:GetText().." "..YCord:GetText().." "..ZCord:GetText() );
end

function GPS()
	outSAY( "gps" );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- WepskScript
function LearnDualWield()
	outSAY( "character advancesk 118 "..WeaponSkillLvl:GetText() );
end

function LearnStaves()
	outSAY( "character advancesk 136 "..WeaponSkillLvl:GetText() );
end

function LearnUnarmed()
	outSAY( "character advancesk 136 "..WeaponSkillLvl:GetText() );
end

function LearnTwoHandedAxes()
	outSAY( "character advancesk 172 "..WeaponSkillLvl:GetText() );
end

function LearnDaggers()
	outSAY( "character advancesk 173 "..WeaponSkillLvl:GetText() );
end

function LearnCrossbows()
	outSAY( "character advancesk 226 "..WeaponSkillLvl:GetText() );
end

function LearnWands()
	outSAY( "character advancesk 228 "..WeaponSkillLvl:GetText() );
end

function LearnPolearms()
	outSAY( "character advancesk 229 "..WeaponSkillLvl:GetText() );
end

function LearnGuns()
	outSAY( "character advancesk 46 "..WeaponSkillLvl:GetText() );
end

function LearnSwords()
	outSAY( "character advancesk 43 "..WeaponSkillLvl:GetText() );
end

function LearnTwoHandedSwords()
	outSAY( "character advancesk 55 "..WeaponSkillLvl:GetText() );
end

function LearnFistWeapons()
	outSAY( "character advancesk 473 "..WeaponSkillLvl:GetText() );
end

function LearnTwoHandedMaces()
	outSAY( "character advancesk 160 "..WeaponSkillLvl:GetText() );
end

function LearnBows()
	outSAY( "character advancesk 45 "..WeaponSkillLvl:GetText() );
end

function LearnThrown()
	outSAY( "character advancesk 176 "..WeaponSkillLvl:GetText() );
end

function LearnAxes()
	outSAY( "character advancesk 44 "..WeaponSkillLvl:GetText() );
end

function LearnMaces()
	outSAY( "character advancesk 54 "..WeaponSkillLvl:GetText() );
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function GMH_Main( msg )
msg = string.lower(msg)
if (msg == "show" or msg == "hide") then
ToggleAddon()
elseif (msg == "") then
	ShowMessage( "GMH Version 1.0.3", "00FF00" );
	ShowMessage( "/gmh - displays this menu", "00FF00" );
	ShowMessage( "/gmh (show or hide) - Shows or Hides GMH", "00FF00" );
	ShowMessage( "/gm (on or off) - Toggles GM", "00FF00" );
	ShowMessage( "/reload - reloads UI - useful for developers", "00FF00" );
	ShowMessage( "/revive - revives yourself", "00FF00" );
	ShowMessage( "/recallport or /recall or /port - Ports yourself to location", "00FF00" );
	ShowMessage( "/npcspawn - spawns NPC - e.g. /npcspawn 1", "00FF00" );
	ShowMessage( "/npcdelete - deleted targeted NPC", "00FF00" );
	ShowMessage( "/additem - adds item to you or target - e.g. /additem 1", "00FF00" );
	ShowMessage( "/announce or /an - broadcasts message to server in chatbox", "00FF00" );
	ShowMessage( "/wannounce or /wan - broadcasts message to server on the screen", "00FF00" );
	ShowMessage( "/gmannounce or /gman - broadcasts message to other GMs in chatbox", "00FF00" );
	ShowMessage( "/savedannounce or /sa - broadcasts saved message", "00FF00" );
	ShowMessage( "/showsavedannounce, /showsaved, or /ssa - Shows you Saved Announcement", "00FF00" );
	ShowMessage( "/advanceall or /advanceallskills - Advances all of your or your target's skills by X.", "00FF00" );
	ShowMessage( "/revive - revives yourself", "00FF00" );
	ShowMessage( "/reviveplr - revives plr x", "00FF00" );
	ShowMessage( "/learn - learns spells to you or targeted player - e.g. /learn all - Learns all spells for your class", "00FF00" );
	ShowMessage( "/unlearn - unlearns spell id on you or targeted player - e.g. /unlearn 1", "00FF00" );
	ShowMessage( "/achievecomplete - Completes achievement on targeted player - e.g. /achievecomplete 1", "00FF00" );
	ShowMessage( "/lookup - Looks up term under specified subject - e.g. /lookup item Gamemaster", "00FF00" );
	ShowMessage( "/kickplayer - Kicks specified player with or without reason. - e.g. /kickplayer Name Reason", "00FF00" );
end
end

function GMH_GMToggle( msg )
msg = string.lower(msg)
	if( msg == "on" or msg == "off" ) then
		outSAY( "gm "..msg );
	else
		ShowMessage( "Available options: on or off", "FF0000" );
	end
end

function GMH_Reload()
	ReloadUI();
end

function GMH_Revive()
	outSAY( "revive" );
end

function GMH_NPCSpawn( msg )
	outSAY( "npc spawn "..msg );
end

function GMH_NPCDelete()
	outSAY( "npc delete" );
end

function GMH_AddItem( msg )
	outSAY( "character additem "..msg );
end

function GMH_Announce( msg )
	outSAY( "announce "..msg );
end

function GMH_WAnnounce( msg )
	outSAY( "wannounce "..msg );
end

function GMH_GMAnnounce( msg )
	outSAY( "gmannounce "..msg );
end

function GMH_RecallPort( msg )
	outSAY( "recall port "..msg );
end

function GMH_SavedAnnounce( msg )
	SaveAnnSend( tonumber( msg ) );
end

function GMH_ShowSavedAnn( msg )
	ShowSavedAnn( tonumber( msg ) );
end

function GMH_Learn( msg )
	outSAY( "char learn "..msg );
end

function GMH_UnLearn( msg )
	outSAY( "char unlearn "..msg );
end

function GMH_Revive( msg )
	outSAY( "revive" );
end

function GMH_RevivePlr( msg )
	outSAY( "reviveplr "..msg );
end

function GMH_AdvanceAllSkills( msg )
	outSAY( "char advanceallskills "..msg );
end

function GMH_AchievementComplete( msg )
	outSAY( "achieve complete "..msg );
end

function GMH_Lookup( msg )
args = {strsplit(" ",msg)};
if(args[2]) then
outSAY( "lookup "..args[1].." "..args[2] );
else
ShowMessage( "Please enter a search term.", "FF0000" );
end
end

function GMH_Kick( msg )
args = {strsplit(" ",msg)};
if(args[2]) then
outSAY( "kickplayer "..args[1].." "..string.sub(msg,string.len(args[1])+2) );
else
outSAY( "kickplayer "..args[1] );
end
end

--Plays sound files named in the DBC
function GMH_Sounds( msg )
	PSound( msg );
end

function GMH_TableReload( msg )
	outSAY( "server reloadtable "..msg );
end

function GMH_ShowMessage ( msg )
ShowMessage(""..msg, "FFFFFF")
end
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
SlashCmdList["GMH"] = GMH_Main;
SLASH_GMH1="/gmh";
SlashCmdList["GMHGMTOGGLE"] = GMH_GMToggle;
SLASH_GMHGMTOGGLE1="/gm";
SlashCmdList["GMHRELOAD"] = GMH_Reload;
SLASH_GMHRELOAD1="/reload";
SlashCmdList["REVIVE"] = GMH_Revive;
SLASH_REVIVE1="/revive";
SlashCmdList["GMHSPAWN"] = GMH_NPCSpawn;
SLASH_GMHSPAWN1="/npcspawn";
SlashCmdList["GMHDELETE"] = GMH_NPCDelete;
SLASH_GMHDELETE1="/npcdelete";
SlashCmdList["GMHADDITEM"] = GMH_AddItem;
SLASH_GMHADDITEM1="/additem";
SlashCmdList["GMHANNOUNCE"] = GMH_Announce;
SLASH_GMHANNOUNCE1="/announce";
SLASH_GMHANNOUNCE2="/an";
SlashCmdList["GMHGMANNOUNCE"] = GMH_GMAnnounce;
SLASH_GMHGMANNOUNCE1="/gmannounce";
SLASH_GMHGMANNOUNCE2="/gman";
SlashCmdList["GMHRECALLPORT"] = GMH_RecallPort;
SLASH_GMHRECALLPORT1="/recallport";
SLASH_GMHRECALLPORT2="/recall";
SLASH_GMHRECALLPORT3="/port";
SlashCmdList["GMHSAVEDANNOUNCE"] = GMH_SavedAnnounce;
SLASH_GMHSAVEDANNOUNCE1="/savedannounce";
SLASH_GMHSAVEDANNOUNCE2="/sa";
SlashCmdList["GMHSHOWSAVEDANNOUNCE"] = GMH_ShowSavedAnn;
SLASH_GMHSHOWSAVEDANNOUNCE1="/showsavedannounce";
SLASH_GMHSHOWSAVEDANNOUNCE2="/showsaved";
SLASH_GMHSHOWSAVEDANNOUNCE3="/ssa";
SlashCmdList["GMHLEARN"] = GMH_Learn;
SLASH_GMHLEARN1="/learn";
SlashCmdList["GMHUNLEARN"] = GMH_UnLearn;
SLASH_GMHUNLEARN1="/unlearn";
SlashCmdList["GMHREVIVE"] = GMH_Revive;
SLASH_GMHREVIVE1="/revive";
SlashCmdList["GMHREVIVEPLR"] = GMH_RevivePlr;
SLASH_GMHREVIVEPLR1="/reviveplr";
SlashCmdList["GMHADVANCEALL"] = GMH_AdvanceAllSkills;
SLASH_GMHADVANCEALL1="/advanceall";
SLASH_GMHADVANCEALL2="/advanceallskills";
SlashCmdList["GMHACHIEVECOMPLETE"] = GMH_AchievementComplete;
SLASH_GMHACHIEVECOMPLETE1="/achievecomplete";
SlashCmdList["GMHLOOKUP"] = GMH_Lookup;
SLASH_GMHLOOKUP1="/lookup";
SlashCmdList["GMHKICK"] = GMH_Kick;
SLASH_GMHKICK1="/kickplayer";
SlashCmdList["GMHSOUND"] = GMH_Sounds;
SLASH_GMHSOUND1="/ps";
SlashCmdList["GMHTR"] = GMH_TableReload;
SLASH_GMHTR1="/tr";
SLASH_GMHTR2="/table";
SlashCmdList["GMHSHOWMESSAGE"] = GMH_ShowMessage;
SLASH_GMHSHOWMESSAGE1="/showmessage";

---------------------------------------------
--		  End of Advance Command		 --
---------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- ItemSearchScript

-- Below vars are used throughout the item search
item_search_results = {}
itemName = {}
itemSearched = false

i = 1;

-- Fired when a server message is sent to the client
function Chat_OnEvent( event, text )
	if string.find( text, "Item" ) and ItemFormSearch:IsShown( ) and not itemSearched then
	if i < 26 then
		-- If the detected string is an item result
		idlength, _, _, _ = string.find( text, ":" );
		item_search_results[i] = string.sub( text, 6, idlength-1 );
		itemName[i] = text;
		ProcessItemSearch( item_search_results[i] );
		i = i + 1;
	end	
	elseif string.find( text, "Search completed in " ) then
	itemSearched = true
	elseif string.find( text, "Starting search of item " ) then -- Reset if its a new search
		for i=1, 25 do
			getglobal( "ItemFormSearchTexture"..i ):Hide( );
			getglobal( "ItemFormSearchLabelItemID"..i ):Hide( );
			getglobal( "ItemFormSearchButton"..i ):Hide( );
			itemSearched = false
		end
		i = 1;
	end
end

-- Function to update each button when a result is recieved by the client
function ProcessItemSearch( itemid )
	getglobal( "ItemFormSearchTexture"..i):Show( );
	getglobal( "ItemFormSearchLabelItemID"..i):Show( );
	getglobal( "ItemFormSearchButton"..i):Show( );
	-- Update "number of results" text
	text = "Results Found: "..i;
	ItemFormSearchLabel2Label:SetText(text);
	getglobal( "ItemFormSearchLabelItemID"..i.."Label" ):SetText( itemName[i] );
	if(GetItemIcon("item:"..itemid)) then
	getglobal( "ItemFormSearchTexture"..i.."Texture" ):SetTexture( GetItemIcon("item:"..itemid) );
	else
	getglobal( "ItemFormSearchTexture"..i.."Texture" ):SetTexture( "Interface\\Icons\\INV_Misc_QuestionMark" );
	end
end

-- When a button is rolled over, show tooltip and update vars based on user cache
function ResultButton_OnEnter( button_number, self )
	GameTooltip:ClearLines( );
	GameTooltip:SetOwner( self, "ANCHOR_RIGHT", -( self:GetWidth( ) / 2 ), 24 )
	GameTooltip:SetHyperlink( "item:"..item_search_results[button_number]..":0:0:0:0:0:0:0" );
	GameTooltip:ClearLines( );
	GameTooltip:AddLine( "|c00B0E0E6"..itemName[button_number] );
	GameTooltip:AddLine( "Click to add to inventory" );
	GameTooltip:Show( );
end

-- Hide the tooltip when mouse leaves a button
function ResultButton_OnLeave( )
	GameTooltip:Hide( );
end

function ResultButton_OnClick( button_number )
outSAY( "character additem "..item_search_results[button_number] );
end
---------------------------------------------
--			End of Item search		   --
---------------------------------------------